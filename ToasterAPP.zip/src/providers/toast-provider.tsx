import { Toaster } from "sonner";

const ToastProvider = () => {
  return <Toaster richColors theme="dark" />;
};

export default ToastProvider;
